package com.githubmanager.app.util

import android.content.Context
import android.net.Uri
import com.githubmanager.app.data.repository.PendingFile
import java.io.ByteArrayOutputStream
import java.util.zip.ZipInputStream

/** A safety ceiling so a huge or malformed zip can't exhaust device memory —
 *  this reads everything into RAM before uploading, which is fine for the
 *  source-code-sized projects this app is meant for. */
private const val MAX_TOTAL_UNCOMPRESSED_BYTES = 200L * 1024 * 1024 // 200 MB

sealed class ZipExtractResult {
    data class Success(val files: List<PendingFile>) : ZipExtractResult()
    data class Error(val message: String) : ZipExtractResult()
}

object ZipUtils {

    /** Unzips the file at [uri] entirely in memory, dropping directory
     *  entries (folders are implicit from file paths, same as git itself). */
    fun extract(context: Context, uri: Uri): ZipExtractResult {
        val files = mutableListOf<PendingFile>()
        var totalBytes = 0L
        try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                ZipInputStream(input).use { zip ->
                    var entry = zip.nextEntry
                    while (entry != null) {
                        if (!entry.isDirectory) {
                            val buffer = ByteArrayOutputStream()
                            val chunk = ByteArray(8 * 1024)
                            var read = zip.read(chunk)
                            while (read != -1) {
                                totalBytes += read
                                if (totalBytes > MAX_TOTAL_UNCOMPRESSED_BYTES) {
                                    return ZipExtractResult.Error("That zip is too large to upload in one go (over 200 MB uncompressed). Try splitting it up.")
                                }
                                buffer.write(chunk, 0, read)
                                read = zip.read(chunk)
                            }
                            val cleanPath = entry.name.trim('/').removePrefix("./")
                            if (cleanPath.isNotBlank()) {
                                files += PendingFile(cleanPath, buffer.toByteArray())
                            }
                        }
                        zip.closeEntry()
                        entry = zip.nextEntry
                    }
                }
            } ?: return ZipExtractResult.Error("Couldn't open that file.")
        } catch (e: Exception) {
            return ZipExtractResult.Error("Couldn't read that zip file: ${e.message ?: "unknown error"}")
        }
        if (files.isEmpty()) return ZipExtractResult.Error("That zip file doesn't contain any files.")
        return ZipExtractResult.Success(files)
    }
}
