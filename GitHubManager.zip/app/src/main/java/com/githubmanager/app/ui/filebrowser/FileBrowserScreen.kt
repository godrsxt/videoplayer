@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.githubmanager.app.ui.filebrowser
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.githubmanager.app.data.model.ContentItem
import com.githubmanager.app.ui.GenericViewModelFactory
import com.githubmanager.app.ui.common.Breadcrumbs
import com.githubmanager.app.ui.common.ConfirmDialog
import com.githubmanager.app.ui.common.EmptyState
import com.githubmanager.app.ui.common.ErrorView
import com.githubmanager.app.ui.common.LoadingIndicator
import com.githubmanager.app.ui.common.TextInputDialog
import com.githubmanager.app.ui.rememberAppContainer
import com.githubmanager.app.util.ClipboardHolder
import com.githubmanager.app.util.formatFileSize
import com.githubmanager.app.util.joinPath

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FileBrowserScreen(
    owner: String,
    repo: String,
    branch: String,
    onOpenFile: (path: String, sha: String) -> Unit,
    onNewFile: (path: String) -> Unit,
    onUploadHere: (targetPath: String) -> Unit
) {
    val container = rememberAppContainer()
    val viewModel: FileBrowserViewModel = viewModel(
        key = "files-$owner-$repo-$branch",
        factory = GenericViewModelFactory {
            FileBrowserViewModel(container.contentsRepository, container.settingsStore, container.treeCache, owner, repo, branch)
        }
    )
    val state by viewModel.uiState.collectAsState()
    val clipboard by ClipboardHolder.state.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    var showNewItemSheet by remember { mutableStateOf(false) }
    var showNewFolderDialog by remember { mutableStateOf(false) }
    var showNewFileDialog by remember { mutableStateOf(false) }
    var renameTarget by remember { mutableStateOf<ContentItem?>(null) }
    var deleteTarget by remember { mutableStateOf<ContentItem?>(null) }
    var deleteSelectedConfirm by remember { mutableStateOf(false) }
    var searchExpanded by remember { mutableStateOf(false) }

    BackHandler(enabled = state.currentPath.isNotBlank() || state.selectionMode) {
        if (state.selectionMode) viewModel.clearSelection() else viewModel.navigateUp()
    }

    LaunchedEffect(state.message) { state.message?.let { snackbarHostState.showSnackbar(it); viewModel.dismissMessage() } }

    Scaffold(
        topBar = {
            Column {
                if (state.selectionMode) {
                    TopAppBar(
                        title = { Text("${state.selectedPaths.size} selected") },
                        navigationIcon = { IconButton(onClick = viewModel::clearSelection) { Icon(Icons.Filled.Close, contentDescription = "Cancel selection") } },
                        actions = {
                            IconButton(onClick = viewModel::copySelected) { Icon(Icons.Filled.ContentCopy, contentDescription = "Copy") }
                            IconButton(onClick = viewModel::cutSelected) { Icon(Icons.Filled.ContentCut, contentDescription = "Cut") }
                            IconButton(onClick = { deleteSelectedConfirm = true }) { Icon(Icons.Filled.Delete, contentDescription = "Delete") }
                        }
                    )
                } else if (searchExpanded) {
                    TopAppBar(
                        title = {
                            OutlinedTextField(
                                value = state.searchQuery,
                                onValueChange = viewModel::search,
                                placeholder = { Text("Search files in this repo") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                        },
                        navigationIcon = {
                            IconButton(onClick = { searchExpanded = false; viewModel.clearSearch() }) { Icon(Icons.Filled.ArrowBack, contentDescription = "Close search") }
                        }
                    )
                } else {
                    TopAppBar(
                        title = { Text(repo, fontWeight = FontWeight.SemiBold) },
                        actions = {
                            IconButton(onClick = { searchExpanded = true }) { Icon(Icons.Filled.Search, contentDescription = "Search") }
                            IconButton(onClick = viewModel::refresh) { Icon(Icons.Filled.Refresh, contentDescription = "Refresh") }
                        }
                    )
                    Breadcrumbs(repoName = repo, path = state.currentPath, onNavigate = viewModel::navigateTo)
                }
                if (!clipboard.isEmpty && !state.selectionMode && !searchExpanded) {
                    ClipboardBar(count = clipboard.entries.size, onPaste = viewModel::pasteHere, onCancel = ClipboardHolder::clear)
                }
            }
        },
        floatingActionButton = {
            if (!state.selectionMode) {
                FloatingActionButton(onClick = { showNewItemSheet = true }) { Icon(Icons.Filled.Add, contentDescription = "New") }
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            val results = state.searchResults
            when {
                searchExpanded && results != null -> {
                    if (state.isSearching) {
                        LoadingIndicator(label = "Searching…")
                    } else if (results.isEmpty()) {
                        EmptyState(title = "No files match", subtitle = "Try a different search term.")
                    } else {
                        LazyColumn {
                            items(results, key = { it.path }) { entry ->
                                ListItem(
                                    headlineContent = { Text(entry.path.substringAfterLast('/')) },
                                    supportingContent = { Text(entry.path, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                    leadingContent = { Icon(Icons.Filled.InsertDriveFile, contentDescription = null) },
                                    modifier = Modifier.clickableItem {
                                        searchExpanded = false
                                        viewModel.clearSearch()
                                        onOpenFile(entry.path, entry.sha ?: "")
                                    }
                                )
                                HorizontalDivider()
                            }
                        }
                    }
                }
                state.isLoading -> LoadingIndicator(label = "Loading…")
                state.error != null && state.items.isEmpty() -> ErrorView(state.error!!, onRetry = viewModel::refresh)
                state.items.isEmpty() -> EmptyState(
                    title = "This folder is empty",
                    subtitle = "Use the + button to add a file, a folder, or upload something from your device.",
                )
                else -> LazyColumn {
                    items(state.visibleItems, key = { it.path }) { item ->
                        FileRow(
                            item = item,
                            selected = item.path in state.selectedPaths,
                            selectionMode = state.selectionMode,
                            onClick = {
                                if (state.selectionMode) {
                                    viewModel.toggleSelected(item.path)
                                } else if (item.type == "dir") {
                                    viewModel.navigateTo(item.path)
                                } else {
                                    onOpenFile(item.path, item.sha)
                                }
                            },
                            onLongClick = { viewModel.toggleSelectionMode(item.path) },
                            onMoreClick = { renameTarget = item }
                        )
                        HorizontalDivider()
                    }
                }
            }
        }
    }

    if (showNewItemSheet) {
        NewItemSheet(
            onDismiss = { showNewItemSheet = false },
            onNewFile = { showNewItemSheet = false; showNewFileDialog = true },
            onNewFolder = { showNewItemSheet = false; showNewFolderDialog = true },
            onUpload = { showNewItemSheet = false; onUploadHere(state.currentPath) }
        )
    }
    if (showNewFolderDialog) {
        TextInputDialog(
            title = "New folder",
            label = "Folder name",
            validate = { if (it.isBlank()) "Enter a name." else null },
            onConfirm = { viewModel.createFolder(it.trim()); showNewFolderDialog = false },
            onDismiss = { showNewFolderDialog = false }
        )
    }
    if (showNewFileDialog) {
        TextInputDialog(
            title = "New file",
            label = "File name",
            placeholder = "example.txt",
            validate = { if (it.isBlank()) "Enter a name." else null },
            onConfirm = { name -> showNewFileDialog = false; onNewFile(joinPath(state.currentPath, name.trim())) },
            onDismiss = { showNewFileDialog = false }
        )
    }
    renameTarget?.let { item ->
        FileActionsSheet(
            item = item,
            onDismiss = { renameTarget = null },
            onRename = { newName -> viewModel.renameItem(item, newName) },
            onDelete = { deleteTarget = item },
            onCutSingle = { viewModel.toggleSelected(item.path); viewModel.cutSelected() },
            onCopySingle = { viewModel.toggleSelected(item.path); viewModel.copySelected() }
        )
    }
    deleteTarget?.let { item ->
        if (state.confirmBeforeDelete) {
            ConfirmDialog(
                title = "Delete ${item.name}?",
                message = if (item.type == "dir") "This deletes the folder and everything inside it." else "This can't be undone.",
                confirmLabel = "Delete",
                destructive = true,
                onConfirm = { viewModel.deleteItem(item); deleteTarget = null; renameTarget = null },
                onDismiss = { deleteTarget = null }
            )
        } else {
            viewModel.deleteItem(item)
            deleteTarget = null
            renameTarget = null
        }
    }
    if (deleteSelectedConfirm) {
        ConfirmDialog(
            title = "Delete ${state.selectedPaths.size} item(s)?",
            message = "This can't be undone.",
            confirmLabel = "Delete",
            destructive = true,
            onConfirm = { viewModel.deleteSelected(); deleteSelectedConfirm = false },
            onDismiss = { deleteSelectedConfirm = false }
        )
    }
}

@Composable
private fun ClipboardBar(count: Int, onPaste: () -> Unit, onCancel: () -> Unit) {
    Surface(color = MaterialTheme.colorScheme.primaryContainer) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("$count item(s) ready to paste", style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
            TextButton(onClick = onCancel) { Text("Cancel") }
            Button(onClick = onPaste) { Text("Paste here") }
        }
    }
}

@Composable
private fun FileRow(
    item: ContentItem,
    selected: Boolean,
    selectionMode: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onMoreClick: () -> Unit
) {
    ListItem(
        headlineContent = { Text(item.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        supportingContent = if (item.type != "dir") {
            { Text(formatFileSize(item.size), style = MaterialTheme.typography.bodySmall) }
        } else null,
        leadingContent = {
            if (selectionMode) {
                Checkbox(checked = selected, onCheckedChange = { onClick() })
            } else {
                Icon(
                    if (item.type == "dir") Icons.Filled.Folder else Icons.Filled.InsertDriveFile,
                    contentDescription = null,
                    tint = if (item.type == "dir") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        trailingContent = if (!selectionMode) {
            { IconButton(onClick = onMoreClick) { Icon(Icons.Filled.MoreVert, contentDescription = "More") } }
        } else null,
        modifier = Modifier.combinedClickableItem(onClick = onClick, onLongClick = onLongClick)
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NewItemSheet(onDismiss: () -> Unit, onNewFile: () -> Unit, onNewFolder: () -> Unit, onUpload: () -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(bottom = 24.dp)) {
            SheetRow(icon = Icons.Filled.NoteAdd, label = "New file", onClick = onNewFile)
            SheetRow(icon = Icons.Filled.CreateNewFolder, label = "New folder", onClick = onNewFolder)
            SheetRow(icon = Icons.Filled.UploadFile, label = "Upload file, folder, or zip", onClick = onUpload)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FileActionsSheet(
    item: ContentItem,
    onDismiss: () -> Unit,
    onRename: (String) -> Unit,
    onDelete: () -> Unit,
    onCutSingle: () -> Unit,
    onCopySingle: () -> Unit
) {
    var showRename by remember { mutableStateOf(false) }
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(bottom = 24.dp)) {
            Text(item.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
            SheetRow(icon = Icons.Filled.DriveFileRenameOutline, label = "Rename", onClick = { showRename = true })
            SheetRow(icon = Icons.Filled.ContentCopy, label = "Copy", onClick = { onCopySingle(); onDismiss() })
            SheetRow(icon = Icons.Filled.ContentCut, label = "Cut", onClick = { onCutSingle(); onDismiss() })
            SheetRow(icon = Icons.Filled.Delete, label = "Delete", destructive = true, onClick = { onDelete(); onDismiss() })
        }
    }
    if (showRename) {
        TextInputDialog(
            title = "Rename",
            label = "New name",
            initialValue = item.name,
            validate = { if (it.isBlank()) "Enter a name." else null },
            onConfirm = { onRename(it.trim()); showRename = false; onDismiss() },
            onDismiss = { showRename = false }
        )
    }
}

@Composable
private fun SheetRow(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, destructive: Boolean = false, onClick: () -> Unit) {
    ListItem(
        headlineContent = { Text(label, color = if (destructive) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface) },
        leadingContent = { Icon(icon, contentDescription = null, tint = if (destructive) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant) },
        modifier = Modifier.clickableItem(onClick)
    )
}

private fun Modifier.clickableItem(onClick: () -> Unit): Modifier = this.clickable(onClick = onClick)

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
private fun Modifier.combinedClickableItem(onClick: () -> Unit, onLongClick: () -> Unit): Modifier =
    this.combinedClickable(onClick = onClick, onLongClick = onLongClick)
