package com.githubmanager.app.data.model

import com.google.gson.annotations.SerializedName

data class WorkflowsResponse(
    @SerializedName("total_count") val totalCount: Int,
    val workflows: List<Workflow>
)

data class Workflow(
    val id: Long,
    val name: String,
    val path: String,
    val state: String, // "active", "disabled_manually", "disabled_inactivity", ...
    @SerializedName("html_url") val htmlUrl: String
)

data class DispatchWorkflowRequest(
    val ref: String,
    val inputs: Map<String, String>? = null
)

data class WorkflowRunsResponse(
    @SerializedName("total_count") val totalCount: Int,
    @SerializedName("workflow_runs") val workflowRuns: List<WorkflowRun>
)

data class WorkflowRun(
    val id: Long,
    @SerializedName("display_title") val displayTitle: String?,
    @SerializedName("head_branch") val headBranch: String?,
    val event: String,
    val status: String, // queued, in_progress, completed
    val conclusion: String?, // success, failure, cancelled, skipped, timed_out, null while running
    @SerializedName("html_url") val htmlUrl: String,
    @SerializedName("created_at") val createdAt: String,
    @SerializedName("run_number") val runNumber: Int
)

data class ArtifactsResponse(
    @SerializedName("total_count") val totalCount: Int,
    val artifacts: List<Artifact>
)

data class Artifact(
    val id: Long,
    val name: String,
    @SerializedName("size_in_bytes") val sizeInBytes: Long,
    val expired: Boolean,
    @SerializedName("created_at") val createdAt: String,
    @SerializedName("workflow_run") val workflowRun: ArtifactWorkflowRunRef? = null
)

data class ArtifactWorkflowRunRef(
    val id: Long,
    @SerializedName("head_branch") val headBranch: String?
)

data class CodeSearchResponse(
    @SerializedName("total_count") val totalCount: Int,
    val items: List<CodeSearchItem>
)

data class CodeSearchItem(
    val name: String,
    val path: String,
    val sha: String
)
