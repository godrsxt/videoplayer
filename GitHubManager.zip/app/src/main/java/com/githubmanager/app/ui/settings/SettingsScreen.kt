@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.githubmanager.app.ui.settings

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.githubmanager.app.data.local.ThemeMode
import com.githubmanager.app.ui.GenericViewModelFactory
import com.githubmanager.app.ui.common.ConfirmDialog
import com.githubmanager.app.ui.common.SectionHeader
import com.githubmanager.app.ui.rememberAppContainer

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(onBack: () -> Unit, onSignedOut: () -> Unit) {
    val container = rememberAppContainer()
    val viewModel: SettingsViewModel = viewModel(
        factory = GenericViewModelFactory {
            SettingsViewModel(container.settingsStore, container.authRepository, container.treeCache, container.accountStore.getCachedUsername())
        }
    )
    val state by viewModel.uiState.collectAsState()
    val settings = state.settings
    val snackbarHostState = remember { SnackbarHostState() }
    var showSignOutConfirm by remember { mutableStateOf(false) }

    LaunchedEffect(state.signedOut) { if (state.signedOut) onSignedOut() }
    LaunchedEffect(state.cacheClearedMessage) {
        state.cacheClearedMessage?.let { snackbarHostState.showSnackbar(it); viewModel.dismissCacheMessage() }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings", fontWeight = FontWeight.SemiBold) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") } }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { padding ->
        LazyColumn(Modifier.padding(padding).fillMaxSize()) {
            item {
                SectionHeader("Account")
                ListItem(
                    headlineContent = { Text(state.username?.let { "@$it" } ?: "Not signed in") },
                    supportingContent = { Text("Signed in with a personal access token") }
                )
                Row(Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                    OutlinedButton(onClick = { showSignOutConfirm = true }) { Text("Sign out") }
                }
            }

            item {
                SectionHeader("Appearance")
                Column(Modifier.padding(horizontal = 16.dp)) {
                    SingleChoiceRow(
                        label = "Theme",
                        options = listOf("System" to ThemeMode.SYSTEM, "Light" to ThemeMode.LIGHT, "Dark" to ThemeMode.DARK),
                        selected = settings.themeMode,
                        onSelect = viewModel::setThemeMode
                    )
                }
            }

            item {
                SectionHeader("Data & loading — turn off what you don't need")
                SwitchRow("Auto-refresh repository list", "Reload your repos every time you open the list, instead of only once", settings.autoRefreshRepoList, viewModel::setAutoRefreshRepoList)
                SwitchRow("Load file previews", "Fetch a quick preview of files as you browse", settings.loadFilePreviews, viewModel::setLoadFilePreviews)
                SwitchRow("Cache repo file tree for search", "Keep a repo's file list in memory so search and navigation are instant", settings.cacheRepoTreeForSearch, viewModel::setCacheRepoTreeForSearch)
                SwitchRow("Auto-refresh workflow runs", "Poll for run status updates while viewing a workflow's runs", settings.autoPollWorkflowRuns, viewModel::setAutoPollWorkflowRuns)
                if (settings.autoPollWorkflowRuns) {
                    SliderRow("Refresh interval", "${settings.pollIntervalSeconds}s", settings.pollIntervalSeconds.toFloat(), 5f, 60f, viewModel::setPollIntervalSeconds)
                }
                SliderRow("Items per page", "${settings.itemsPerPage}", settings.itemsPerPage.toFloat(), 10f, 100f, viewModel::setItemsPerPage)
            }

            item {
                SectionHeader("Safety")
                SwitchRow("Confirm before delete", "Ask before deleting files, folders, or repositories", settings.confirmBeforeDelete, viewModel::setConfirmBeforeDelete)
                SwitchRow("Show hidden files", "Show dotfiles like .gitignore in the file browser", settings.showHiddenFiles, viewModel::setShowHiddenFiles)
            }

            item {
                SectionHeader("Storage")
                ListItem(
                    headlineContent = { Text("Clear cached file trees") },
                    supportingContent = { Text("Frees the in-memory cache used for search and navigation") },
                    trailingContent = { TextButton(onClick = viewModel::clearCache) { Text("Clear") } }
                )
            }

            item { Spacer(Modifier.height(32.dp)) }
        }
    }

    if (showSignOutConfirm) {
        ConfirmDialog(
            title = "Sign out?",
            message = "You'll need your token again to sign back in.",
            confirmLabel = "Sign out",
            destructive = true,
            onConfirm = { viewModel.signOut(); showSignOutConfirm = false },
            onDismiss = { showSignOutConfirm = false }
        )
    }
}

@Composable
private fun SwitchRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    ListItem(
        headlineContent = { Text(title) },
        supportingContent = { Text(subtitle, style = MaterialTheme.typography.bodySmall) },
        trailingContent = { Switch(checked = checked, onCheckedChange = onChange) }
    )
}

@Composable
private fun SliderRow(title: String, valueLabel: String, value: Float, min: Float, max: Float, onChange: (Int) -> Unit) {
    Column(Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(valueLabel, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Slider(value = value, onValueChange = { onChange(it.toInt()) }, valueRange = min..max)
    }
}

@Composable
private fun <T> SingleChoiceRow(label: String, options: List<Pair<String, T>>, selected: T, onSelect: (T) -> Unit) {
    Column(Modifier.padding(vertical = 8.dp)) {
        Text(label, style = MaterialTheme.typography.bodyLarge)
        Spacer(Modifier.height(6.dp))
        Row {
            options.forEach { (text, value) ->
                FilterChip(
                    selected = value == selected,
                    onClick = { onSelect(value) },
                    label = { Text(text) },
                    modifier = Modifier.padding(end = 8.dp)
                )
            }
        }
    }
}
