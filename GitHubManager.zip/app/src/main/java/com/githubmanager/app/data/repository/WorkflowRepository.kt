package com.githubmanager.app.data.repository

import com.githubmanager.app.data.model.*
import com.githubmanager.app.data.remote.ApiResult
import com.githubmanager.app.data.remote.GitHubApiService
import com.githubmanager.app.data.remote.safeApiCall
import com.githubmanager.app.util.encodeGitPath

class WorkflowRepository(private val api: GitHubApiService) {

    suspend fun listWorkflows(owner: String, repo: String): ApiResult<List<Workflow>> {
        return when (val result = safeApiCall { api.listWorkflows(owner, repo) }) {
            is ApiResult.Success -> ApiResult.Success(result.data.workflows)
            is ApiResult.Error -> result
        }
    }

    suspend fun setEnabled(owner: String, repo: String, workflowId: Long, enabled: Boolean): ApiResult<Unit> =
        if (enabled) safeApiCall { api.enableWorkflow(owner, repo, workflowId) }
        else safeApiCall { api.disableWorkflow(owner, repo, workflowId) }

    /** Triggers a workflow_dispatch run. Requires the workflow file itself to
     *  declare `on: workflow_dispatch` — GitHub returns a 422 otherwise,
     *  which safeApiCall already turns into a readable message. */
    suspend fun dispatch(owner: String, repo: String, workflowId: Long, ref: String, inputs: Map<String, String>? = null): ApiResult<Unit> =
        safeApiCall { api.dispatchWorkflow(owner, repo, workflowId, DispatchWorkflowRequest(ref, inputs)) }

    /** "Deleting a workflow" means removing its YAML file from the repo —
     *  GitHub doesn't have a separate concept of a standalone workflow
     *  definition to delete. */
    suspend fun deleteWorkflowFile(owner: String, repo: String, path: String, sha: String, branch: String): ApiResult<FileCommitResponse> =
        safeApiCall { api.deleteFile(owner, repo, encodeGitPath(path), DeleteFileRequest("Delete workflow $path", sha, branch)) }

    suspend fun listRuns(owner: String, repo: String, workflowId: Long): ApiResult<List<WorkflowRun>> {
        return when (val result = safeApiCall { api.listWorkflowRuns(owner, repo, workflowId) }) {
            is ApiResult.Success -> ApiResult.Success(result.data.workflowRuns)
            is ApiResult.Error -> result
        }
    }

    suspend fun cancelRun(owner: String, repo: String, runId: Long): ApiResult<Unit> =
        safeApiCall { api.cancelRun(owner, repo, runId) }

    suspend fun deleteRun(owner: String, repo: String, runId: Long): ApiResult<Unit> =
        safeApiCall { api.deleteRun(owner, repo, runId) }
}
