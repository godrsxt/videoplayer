package com.githubmanager.app.data.repository

import android.util.Base64
import com.githubmanager.app.data.model.*
import com.githubmanager.app.data.remote.ApiResult
import com.githubmanager.app.data.remote.GitHubApiService
import com.githubmanager.app.data.remote.safeApiCall
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit

/** A file to be written: its path within the repo, and its raw bytes. */
data class PendingFile(val path: String, val bytes: ByteArray)

/**
 * Every "bulk" operation in the app — uploading a picked folder or a zip,
 * moving/copying/deleting a folder, duplicating a whole repository — goes
 * through here. The key idea, straight from the Git Data API: a tree can be
 * rewritten by listing only the *changed* paths against a `base_tree`;
 * unlisted paths carry over unchanged, and a path with `sha: null` is
 * removed. That turns an operation on thousands of files into a fixed
 * number of API calls (uploads aside) instead of one call per file.
 */
class GitTreeEngine(private val api: GitHubApiService) {

    private val uploadConcurrency = Semaphore(5)

    /** Full recursive tree listing for a branch (or any ref/sha). */
    suspend fun getRecursiveTree(owner: String, repo: String, ref: String): ApiResult<GitTree> =
        safeApiCall { api.getTree(owner, repo, ref, recursive = 1) }

    /**
     * Uploads [files] as new blobs, then folds them into a single new tree,
     * commit, and branch update. Works whether [branch] already has commits
     * (existing repo — unrelated files are preserved via `base_tree`) or not
     * (brand-new repo — this becomes the first commit and the branch ref is
     * created rather than updated).
     */
    suspend fun pushFiles(
        owner: String,
        repo: String,
        branch: String,
        message: String,
        files: List<PendingFile>,
        onProgress: (done: Int, total: Int) -> Unit = { _, _ -> }
    ): ApiResult<String> = coroutineScope {
        if (files.isEmpty()) return@coroutineScope ApiResult.Error("Nothing to upload.")

        val refResult = safeApiCall { api.getRef(owner, repo, "heads/$branch") }
        val baseCommitSha: String? = (refResult as? ApiResult.Success)?.data?.objectRef?.sha
        var baseTreeSha: String? = null
        if (baseCommitSha != null) {
            val commitResult = safeApiCall { api.getCommit(owner, repo, baseCommitSha) }
            if (commitResult is ApiResult.Error) return@coroutineScope commitResult
            baseTreeSha = (commitResult as ApiResult.Success).data.tree.sha
        }

        var completed = 0
        val progressLock = Any()
        val uploaded = files.map { file ->
            async {
                val result = uploadConcurrency.withPermit {
                    safeApiCall {
                        api.createBlob(
                            owner, repo,
                            CreateBlobRequest(content = Base64.encodeToString(file.bytes, Base64.NO_WRAP))
                        )
                    }
                }
                synchronized(progressLock) { completed++; onProgress(completed, files.size) }
                file.path to result
            }
        }.awaitAll()

        val failed = uploaded.firstOrNull { it.second is ApiResult.Error }
        if (failed != null) return@coroutineScope failed.second as ApiResult.Error

        val treeEntries = uploaded.map { (path, result) ->
            GitTreeEntry(path = path, mode = "100644", type = "blob", sha = (result as ApiResult.Success).data.sha)
        }

        val treeResult = safeApiCall { api.createTree(owner, repo, CreateTreeRequest(baseTree = baseTreeSha, tree = treeEntries)) }
        if (treeResult is ApiResult.Error) return@coroutineScope treeResult
        val newTreeSha = (treeResult as ApiResult.Success).data.sha

        val parents = baseCommitSha?.let { listOf(it) } ?: emptyList()
        val commitResult = safeApiCall { api.createCommit(owner, repo, CreateCommitRequest(message, newTreeSha, parents)) }
        if (commitResult is ApiResult.Error) return@coroutineScope commitResult
        val newCommitSha = (commitResult as ApiResult.Success).data.sha

        val refUpdate = if (baseCommitSha != null) {
            safeApiCall { api.updateRef(owner, repo, "heads/$branch", UpdateRefRequest(sha = newCommitSha)) }
        } else {
            safeApiCall { api.createRef(owner, repo, CreateRefRequest(ref = "refs/heads/$branch", sha = newCommitSha)) }
        }
        if (refUpdate is ApiResult.Error) return@coroutineScope refUpdate

        ApiResult.Success(newCommitSha)
    }

    /**
     * Applies raw tree-entry changes (adds, moves, deletes — referencing
     * *existing* blob shas, so no content is re-uploaded) on top of the
     * branch's current tree, as one commit. This is what powers folder
     * move/copy/delete: cheap regardless of how many files are inside.
     */
    suspend fun applyTreeChanges(
        owner: String,
        repo: String,
        branch: String,
        message: String,
        changes: List<GitTreeEntry>
    ): ApiResult<String> {
        val refResult = safeApiCall { api.getRef(owner, repo, "heads/$branch") }
        if (refResult is ApiResult.Error) return refResult
        val baseCommitSha = (refResult as ApiResult.Success).data.objectRef.sha

        val commitResult = safeApiCall { api.getCommit(owner, repo, baseCommitSha) }
        if (commitResult is ApiResult.Error) return commitResult
        val baseTreeSha = (commitResult as ApiResult.Success).data.tree.sha

        val treeResult = safeApiCall { api.createTree(owner, repo, CreateTreeRequest(baseTree = baseTreeSha, tree = changes)) }
        if (treeResult is ApiResult.Error) return treeResult
        val newTreeSha = (treeResult as ApiResult.Success).data.sha

        val newCommitResult = safeApiCall {
            api.createCommit(owner, repo, CreateCommitRequest(message, newTreeSha, listOf(baseCommitSha)))
        }
        if (newCommitResult is ApiResult.Error) return newCommitResult
        val newCommitSha = (newCommitResult as ApiResult.Success).data.sha

        val updateResult = safeApiCall { api.updateRef(owner, repo, "heads/$branch", UpdateRefRequest(sha = newCommitSha)) }
        if (updateResult is ApiResult.Error) return updateResult

        return ApiResult.Success(newCommitSha)
    }
}
