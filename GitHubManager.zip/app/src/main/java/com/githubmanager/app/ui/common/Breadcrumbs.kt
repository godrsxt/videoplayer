package com.githubmanager.app.ui.common

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/** Renders "repoName / folder / subfolder", each segment tappable, plus a
 *  home icon that always jumps straight back to the repo root regardless of
 *  how deep the current path is. */
@Composable
fun Breadcrumbs(
    repoName: String,
    path: String,
    onNavigate: (path: String) -> Unit,
    modifier: Modifier = Modifier
) {
    val segments = path.trim('/').split("/").filter { it.isNotBlank() }
    Row(
        modifier = modifier
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            Icons.Filled.Home,
            contentDescription = "Jump to root",
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier
                .padding(end = 4.dp)
                .clickable { onNavigate("") }
        )
        Text(
            repoName,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier
                .clickable { onNavigate("") }
                .padding(horizontal = 2.dp)
        )
        var accPath = ""
        for (segment in segments) {
            accPath = if (accPath.isBlank()) segment else "$accPath/$segment"
            val target = accPath
            Icon(
                Icons.Filled.ChevronRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 2.dp)
            )
            Text(
                segment,
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier
                    .clickable { onNavigate(target) }
                    .padding(horizontal = 2.dp)
            )
        }
    }
}
