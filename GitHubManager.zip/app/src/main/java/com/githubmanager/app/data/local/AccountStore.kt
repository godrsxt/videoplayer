package com.githubmanager.app.data.local

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

private val Context.accountDataStore by preferencesDataStore(name = "account_store")

/**
 * Holds the signed-in GitHub username and personal access token — both
 * entered directly on the in-app login screen. The username is plain text
 * (a GitHub handle isn't a secret); the token is encrypted at rest with a
 * key held in the Android Keystore, hardware-backed on devices that support
 * it, and never leaves the keystore itself — only ciphertext touches disk.
 */
class AccountStore(private val context: Context) {

    companion object {
        private const val KEY_ALIAS = "github_manager_token_key"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
        private val USERNAME_KEY = stringPreferencesKey("github_username")
        private val TOKEN_KEY = stringPreferencesKey("encrypted_token")
    }

    @Volatile private var cachedUsername: String? = null
    @Volatile private var cachedToken: String? = null

    val usernameFlow: Flow<String?> = context.accountDataStore.data.map { it[USERNAME_KEY] }

    /** Populates the in-memory cache from disk. Call once at app startup,
     *  before any screen might need the token. */
    suspend fun initialize() {
        val prefs = context.accountDataStore.data.first()
        cachedUsername = prefs[USERNAME_KEY]
        cachedToken = prefs[TOKEN_KEY]?.let { runCatching { decrypt(it) }.getOrNull() }
    }

    fun getCachedUsername(): String? = cachedUsername
    fun getCachedToken(): String? = cachedToken
    fun isSignedIn(): Boolean = !cachedToken.isNullOrBlank()

    suspend fun saveAccount(username: String, token: String) {
        val encrypted = encrypt(token)
        context.accountDataStore.edit { prefs ->
            prefs[USERNAME_KEY] = username
            prefs[TOKEN_KEY] = encrypted
        }
        cachedUsername = username
        cachedToken = token
    }

    /** Updates just the username — used after sign-in to reconcile whatever
     *  was typed with the account the token actually belongs to. */
    suspend fun updateUsername(username: String) {
        context.accountDataStore.edit { prefs -> prefs[USERNAME_KEY] = username }
        cachedUsername = username
    }

    suspend fun signOut() {
        context.accountDataStore.edit { it.clear() }
        cachedUsername = null
        cachedToken = null
    }

    private fun getOrCreateKey(): SecretKey {
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (keyStore.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }

        val keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        val spec = KeyGenParameterSpec.Builder(
            KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .build()
        keyGenerator.init(spec)
        return keyGenerator.generateKey()
    }

    private fun encrypt(plainText: String): String {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val iv = cipher.iv
        val cipherBytes = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(iv + cipherBytes, Base64.NO_WRAP)
    }

    private fun decrypt(stored: String): String {
        val combined = Base64.decode(stored, Base64.NO_WRAP)
        val iv = combined.copyOfRange(0, 12)
        val cipherBytes = combined.copyOfRange(12, combined.size)
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, iv))
        return String(cipher.doFinal(cipherBytes), Charsets.UTF_8)
    }
}
