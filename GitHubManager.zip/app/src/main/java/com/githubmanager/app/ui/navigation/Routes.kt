package com.githubmanager.app.ui.navigation

import java.net.URLDecoder
import java.net.URLEncoder

/**
 * Only screens that make sense as their own back-stack entry get a route:
 * signing in, the repo list, settings, the repo workspace (which hosts
 * Files/Workflows/Artifacts tabs and handles folder drill-down and workflow
 * run drill-down as internal state, not nav destinations — a file browser's
 * "up a folder" is not a new screen), the file editor, and the upload flow.
 */
object Routes {
    const val LOGIN = "login"
    const val REPOS = "repos"
    const val SETTINGS = "settings"

    const val REPO_DETAIL = "repo/{owner}/{repo}"
    const val FILE_EDITOR = "editor?owner={owner}&repo={repo}&path={path}&branch={branch}&sha={sha}&isNew={isNew}"
    const val UPLOAD = "upload?owner={owner}&repo={repo}&targetPath={targetPath}&branch={branch}"

    fun repoDetail(owner: String, repo: String) = "repo/${enc(owner)}/${enc(repo)}"

    fun fileEditor(owner: String, repo: String, path: String, branch: String, sha: String?, isNew: Boolean) =
        "editor?owner=${enc(owner)}&repo=${enc(repo)}&path=${enc(path)}&branch=${enc(branch)}&sha=${enc(sha ?: "")}&isNew=$isNew"

    fun upload(owner: String, repo: String, targetPath: String, branch: String) =
        "upload?owner=${enc(owner)}&repo=${enc(repo)}&targetPath=${enc(targetPath)}&branch=${enc(branch)}"

    /** Empty owner/repo signals "create a new repository from this upload"
     *  to the upload screen, rather than pushing into an existing one. */
    fun uploadToNewRepo() = "upload?owner=&repo=&targetPath=&branch="

    private fun enc(value: String) = URLEncoder.encode(value, "UTF-8")
    fun dec(value: String?) = if (value.isNullOrBlank()) "" else URLDecoder.decode(value, "UTF-8")
}
