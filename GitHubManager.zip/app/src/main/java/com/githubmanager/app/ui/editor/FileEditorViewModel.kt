package com.githubmanager.app.ui.editor

import android.util.Base64
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.githubmanager.app.data.remote.ApiResult
import com.githubmanager.app.data.repository.ContentsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class FileEditorUiState(
    val isLoading: Boolean = true,
    val text: String = "",
    val originalText: String = "",
    val sha: String? = null,
    val isBinaryOrTooLarge: Boolean = false,
    val isSaving: Boolean = false,
    val error: String? = null,
    val saved: Boolean = false
) {
    val isDirty: Boolean get() = text != originalText
}

class FileEditorViewModel(
    private val contentsRepository: ContentsRepository,
    private val owner: String,
    private val repo: String,
    private val branch: String,
    private val path: String,
    private val isNewFile: Boolean,
    initialSha: String?
) : ViewModel() {

    private val _uiState = MutableStateFlow(FileEditorUiState(sha = initialSha, isLoading = !isNewFile))
    val uiState: StateFlow<FileEditorUiState> = _uiState

    init {
        if (!isNewFile) load()
    }

    private fun load() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            when (val result = contentsRepository.getFile(owner, repo, path, branch)) {
                is ApiResult.Success -> {
                    val item = result.data
                    if (item.encoding == "base64" && item.content != null) {
                        try {
                            val bytes = Base64.decode(item.content.replace("\n", ""), Base64.DEFAULT)
                            val text = String(bytes, Charsets.UTF_8)
                            _uiState.update { it.copy(isLoading = false, text = text, originalText = text, sha = item.sha) }
                        } catch (e: Exception) {
                            _uiState.update { it.copy(isLoading = false, isBinaryOrTooLarge = true, sha = item.sha) }
                        }
                    } else {
                        _uiState.update { it.copy(isLoading = false, isBinaryOrTooLarge = true, sha = item.sha) }
                    }
                }
                is ApiResult.Error -> _uiState.update { it.copy(isLoading = false, error = result.message) }
            }
        }
    }

    fun onTextChange(value: String) = _uiState.update { it.copy(text = value) }

    fun save(commitMessage: String) {
        val state = _uiState.value
        viewModelScope.launch {
            _uiState.update { it.copy(isSaving = true, error = null) }
            val bytes = state.text.toByteArray(Charsets.UTF_8)
            val message = commitMessage.ifBlank { if (isNewFile) "Create $path" else "Update $path" }
            when (val result = contentsRepository.createOrUpdateFile(owner, repo, path, bytes, message, branch, existingSha = if (isNewFile) null else state.sha)) {
                is ApiResult.Success -> _uiState.update {
                    it.copy(isSaving = false, saved = true, originalText = it.text, sha = result.data.content?.sha ?: it.sha)
                }
                is ApiResult.Error -> _uiState.update { it.copy(isSaving = false, error = result.message) }
            }
        }
    }

    fun dismissError() = _uiState.update { it.copy(error = null) }
    fun consumeSaved() = _uiState.update { it.copy(saved = false) }
}
