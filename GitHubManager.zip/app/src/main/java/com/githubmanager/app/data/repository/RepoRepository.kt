package com.githubmanager.app.data.repository

import android.util.Base64
import com.githubmanager.app.data.model.*
import com.githubmanager.app.data.remote.ApiResult
import com.githubmanager.app.data.remote.GitHubApiService
import com.githubmanager.app.data.remote.safeApiCall
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit

class RepoRepository(private val api: GitHubApiService) {

    private val treeEngine = GitTreeEngine(api)
    private val fetchConcurrency = Semaphore(5)

    suspend fun listRepos(page: Int = 1, perPage: Int = 30): ApiResult<List<Repo>> =
        safeApiCall { api.listRepos(perPage = perPage, page = page) }

    suspend fun createRepo(name: String, description: String?, private: Boolean, autoInit: Boolean = true): ApiResult<Repo> =
        safeApiCall { api.createRepo(CreateRepoRequest(name = name, description = description, isPrivate = private, autoInit = autoInit)) }

    suspend fun getRepo(owner: String, repo: String): ApiResult<Repo> =
        safeApiCall { api.getRepo(owner, repo) }

    suspend fun updateRepo(owner: String, repo: String, body: UpdateRepoRequest): ApiResult<Repo> =
        safeApiCall { api.updateRepo(owner, repo, body) }

    suspend fun deleteRepo(owner: String, repo: String): ApiResult<Unit> =
        safeApiCall { api.deleteRepo(owner, repo) }

    suspend fun forkRepo(owner: String, repo: String): ApiResult<Repo> =
        safeApiCall { api.forkRepo(owner, repo) }

    suspend fun listBranches(owner: String, repo: String): ApiResult<List<Branch>> =
        safeApiCall { api.listBranches(owner, repo) }

    /**
     * Creates a fully independent copy of a repository under a new name —
     * unlike a fork, there's no link back to the original afterwards. GitHub
     * has no server-side "copy" endpoint, so this fetches every blob's
     * content from the source and re-creates it in the destination
     * (bounded concurrency), then writes one tree/commit for the lot. Slower
     * than a fork for large repos; [onProgress] reports blob-by-blob so the
     * UI can show real progress.
     */
    suspend fun duplicateRepo(
        sourceOwner: String, sourceRepo: String, sourceBranch: String,
        newName: String, private: Boolean, description: String?,
        onProgress: (done: Int, total: Int) -> Unit
    ): ApiResult<Repo> = coroutineScope {
        val treeResult = treeEngine.getRecursiveTree(sourceOwner, sourceRepo, sourceBranch)
        if (treeResult is ApiResult.Error) return@coroutineScope treeResult
        val blobs = (treeResult as ApiResult.Success).data.tree.filter { it.type == "blob" }
        if (blobs.isEmpty()) return@coroutineScope ApiResult.Error("Source repository has no files to copy.")

        val createResult = createRepo(newName, description, private, autoInit = false)
        if (createResult is ApiResult.Error) return@coroutineScope createResult
        val newRepo = (createResult as ApiResult.Success).data

        var completed = 0
        val progressLock = Any()
        val fetched = blobs.map { entry ->
            async {
                val result = fetchConcurrency.withPermit {
                    safeApiCall { api.getBlob(sourceOwner, sourceRepo, entry.sha!!) }
                }
                synchronized(progressLock) { completed++; onProgress(completed, blobs.size) }
                entry.path to result
            }
        }.awaitAll()

        val failed = fetched.firstOrNull { it.second is ApiResult.Error }
        if (failed != null) return@coroutineScope failed.second as ApiResult.Error

        val files = fetched.map { (path, result) ->
            val blob = (result as ApiResult.Success).data
            val bytes = if (blob.content != null) Base64.decode(blob.content.replace("\n", ""), Base64.DEFAULT) else ByteArray(0)
            PendingFile(path, bytes)
        }

        val pushResult = treeEngine.pushFiles(
            newRepo.owner.login, newRepo.name, newRepo.defaultBranch,
            "Initial copy from $sourceOwner/$sourceRepo", files
        )
        if (pushResult is ApiResult.Error) return@coroutineScope pushResult

        ApiResult.Success(newRepo)
    }
}
