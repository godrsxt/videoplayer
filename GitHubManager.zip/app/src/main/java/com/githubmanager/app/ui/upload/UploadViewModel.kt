package com.githubmanager.app.ui.upload

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.githubmanager.app.data.remote.ApiResult
import com.githubmanager.app.data.repository.PendingFile
import com.githubmanager.app.data.repository.RepoRepository
import com.githubmanager.app.data.repository.UploadRepository
import com.githubmanager.app.util.DocumentTreeUtils
import com.githubmanager.app.util.FolderReadResult
import com.githubmanager.app.util.ZipExtractResult
import com.githubmanager.app.util.ZipUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class UploadUiState(
    val isNewRepoMode: Boolean = false,
    val newRepoName: String = "",
    val newRepoPrivate: Boolean = true,
    val targetPath: String = "",
    val pickedFiles: List<PendingFile> = emptyList(),
    val pickedSourceLabel: String = "",
    val isReading: Boolean = false,
    val isUploading: Boolean = false,
    val progress: Pair<Int, Int>? = null,
    val commitMessage: String = "",
    val error: String? = null,
    val done: Boolean = false
) {
    val totalBytes: Long get() = pickedFiles.sumOf { it.bytes.size.toLong() }
}

class UploadViewModel(
    private val uploadRepository: UploadRepository,
    private val repoRepository: RepoRepository,
    private val owner: String,
    private val repo: String,
    private val branch: String,
    targetPath: String
) : ViewModel() {

    private val _uiState = MutableStateFlow(
        UploadUiState(isNewRepoMode = owner.isBlank() || repo.isBlank(), targetPath = targetPath)
    )
    val uiState: StateFlow<UploadUiState> = _uiState

    fun onNewRepoNameChange(value: String) = _uiState.update { it.copy(newRepoName = value) }
    fun onNewRepoPrivateChange(value: Boolean) = _uiState.update { it.copy(newRepoPrivate = value) }
    fun onTargetPathChange(value: String) = _uiState.update { it.copy(targetPath = value) }
    fun onCommitMessageChange(value: String) = _uiState.update { it.copy(commitMessage = value) }

    fun pickZip(context: Context, uri: Uri) {
        viewModelScope.launch {
            _uiState.update { it.copy(isReading = true, error = null) }
            val result = withContext(Dispatchers.IO) { ZipUtils.extract(context, uri) }
            when (result) {
                is ZipExtractResult.Success -> _uiState.update {
                    it.copy(isReading = false, pickedFiles = result.files, pickedSourceLabel = "Zip archive (${result.files.size} files)")
                }
                is ZipExtractResult.Error -> _uiState.update { it.copy(isReading = false, error = result.message) }
            }
        }
    }

    fun pickFolder(context: Context, treeUri: Uri) {
        viewModelScope.launch {
            _uiState.update { it.copy(isReading = true, error = null) }
            val result = withContext(Dispatchers.IO) { DocumentTreeUtils.readFolder(context, treeUri) }
            when (result) {
                is FolderReadResult.Success -> _uiState.update {
                    it.copy(isReading = false, pickedFiles = result.files, pickedSourceLabel = "Folder (${result.files.size} files)")
                }
                is FolderReadResult.Error -> _uiState.update { it.copy(isReading = false, error = result.message) }
            }
        }
    }

    fun pickIndividualFiles(context: Context, uris: List<Uri>) {
        viewModelScope.launch {
            _uiState.update { it.copy(isReading = true, error = null) }
            val files = withContext(Dispatchers.IO) {
                uris.mapNotNull { uri ->
                    val name = queryDisplayName(context, uri) ?: return@mapNotNull null
                    val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return@mapNotNull null
                    PendingFile(name, bytes)
                }
            }
            if (files.isEmpty()) {
                _uiState.update { it.copy(isReading = false, error = "Couldn't read the selected file(s).") }
            } else {
                _uiState.update { it.copy(isReading = false, pickedFiles = files, pickedSourceLabel = "${files.size} file(s)") }
            }
        }
    }

    private fun queryDisplayName(context: Context, uri: Uri): String? {
        var name: String? = null
        context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val idx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) name = cursor.getString(idx)
            }
        }
        return name
    }

    fun upload() {
        val state = _uiState.value
        if (state.pickedFiles.isEmpty()) {
            _uiState.update { it.copy(error = "Pick a file, folder, or zip first.") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isUploading = true, error = null, progress = 0 to state.pickedFiles.size) }

            var targetOwner = owner
            var targetRepo = repo
            var targetBranch = branch

            if (state.isNewRepoMode) {
                if (state.newRepoName.isBlank()) {
                    _uiState.update { it.copy(isUploading = false, error = "Enter a name for the new repository.") }
                    return@launch
                }
                when (val createResult = repoRepository.createRepo(state.newRepoName.trim(), null, state.newRepoPrivate, autoInit = false)) {
                    is ApiResult.Success -> {
                        targetOwner = createResult.data.owner.login
                        targetRepo = createResult.data.name
                        targetBranch = createResult.data.defaultBranch
                    }
                    is ApiResult.Error -> {
                        _uiState.update { it.copy(isUploading = false, error = createResult.message) }
                        return@launch
                    }
                }
            }

            val message = state.commitMessage.ifBlank { "Add ${state.pickedFiles.size} file(s) via GitHub Manager" }
            val result = uploadRepository.uploadFiles(
                targetOwner, targetRepo, targetBranch, state.targetPath, state.pickedFiles, message
            ) { done, total -> _uiState.update { it.copy(progress = done to total) } }

            when (result) {
                is ApiResult.Success -> _uiState.update { it.copy(isUploading = false, done = true) }
                is ApiResult.Error -> _uiState.update { it.copy(isUploading = false, error = result.message) }
            }
        }
    }

    fun dismissError() = _uiState.update { it.copy(error = null) }
}
