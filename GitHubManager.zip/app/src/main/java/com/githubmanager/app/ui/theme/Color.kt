package com.githubmanager.app.ui.theme

import androidx.compose.ui.graphics.Color

// Dark palette
val DarkBackground = Color(0xFF0D1117)
val DarkSurface = Color(0xFF161B22)
val DarkSurfaceVariant = Color(0xFF21262D)
val DarkOutline = Color(0xFF30363D)
val DarkOnBackground = Color(0xFFE6EDF3)
val DarkOnSurfaceMuted = Color(0xFF8B949E)
val DarkGreen = Color(0xFF3FB950)
val DarkGreenContainer = Color(0xFF1B3A24)
val DarkGold = Color(0xFFE3B341)
val DarkRed = Color(0xFFF85149)
val DarkRedContainer = Color(0xFF3D1418)
val DarkBlue = Color(0xFF58A6FF)

// Light palette
val LightBackground = Color(0xFFFFFFFF)
val LightSurface = Color(0xFFF6F8FA)
val LightSurfaceVariant = Color(0xFFEAEEF2)
val LightOutline = Color(0xFFD0D7DE)
val LightOnBackground = Color(0xFF1F2328)
val LightOnSurfaceMuted = Color(0xFF59636E)
val LightGreen = Color(0xFF1A7F37)
val LightGreenContainer = Color(0xFFD8F5DE)
val LightGold = Color(0xFF9A6700)
val LightRed = Color(0xFFCF222E)
val LightRedContainer = Color(0xFFFFEBE9)
val LightBlue = Color(0xFF0969DA)
