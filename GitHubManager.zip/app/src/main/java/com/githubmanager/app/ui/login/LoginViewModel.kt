package com.githubmanager.app.ui.login

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.githubmanager.app.data.remote.ApiResult
import com.githubmanager.app.data.repository.AuthRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class LoginUiState(
    val username: String = "",
    val token: String = "",
    val isLoading: Boolean = false,
    val error: String? = null,
    val signedIn: Boolean = false
)

class LoginViewModel(private val authRepository: AuthRepository) : ViewModel() {

    private val _uiState = MutableStateFlow(LoginUiState())
    val uiState: StateFlow<LoginUiState> = _uiState

    fun onUsernameChange(value: String) = _uiState.update { it.copy(username = value, error = null) }
    fun onTokenChange(value: String) = _uiState.update { it.copy(token = value, error = null) }

    fun signIn() {
        val state = _uiState.value
        if (state.username.isBlank() || state.token.isBlank()) {
            _uiState.update { it.copy(error = "Enter both your GitHub username and a personal access token.") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            when (val result = authRepository.signIn(state.username, state.token)) {
                is ApiResult.Success -> _uiState.update { it.copy(isLoading = false, signedIn = true) }
                is ApiResult.Error -> _uiState.update { it.copy(isLoading = false, error = result.message) }
            }
        }
    }
}
