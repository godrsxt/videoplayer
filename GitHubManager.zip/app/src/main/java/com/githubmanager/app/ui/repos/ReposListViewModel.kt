package com.githubmanager.app.ui.repos

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.githubmanager.app.data.local.SettingsStore
import com.githubmanager.app.data.model.Repo
import com.githubmanager.app.data.model.UpdateRepoRequest
import com.githubmanager.app.data.remote.ApiResult
import com.githubmanager.app.data.repository.RepoRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ReposUiState(
    val isLoading: Boolean = false,
    val repos: List<Repo> = emptyList(),
    val query: String = "",
    val error: String? = null,
    val hasLoadedOnce: Boolean = false,
    val actionInProgress: String? = null, // repo full_name currently being acted on
    val duplicateProgress: Pair<Int, Int>? = null,
    val message: String? = null
) {
    val filteredRepos: List<Repo>
        get() = if (query.isBlank()) repos else repos.filter {
            it.name.contains(query, ignoreCase = true) || it.description?.contains(query, ignoreCase = true) == true
        }
}

class ReposListViewModel(
    private val repoRepository: RepoRepository,
    private val settingsStore: SettingsStore
) : ViewModel() {

    private val _uiState = MutableStateFlow(ReposUiState())
    val uiState: StateFlow<ReposUiState> = _uiState

    fun onScreenVisible() {
        viewModelScope.launch {
            val settings = settingsStore.settingsFlow.first()
            val alreadyLoaded = _uiState.value.hasLoadedOnce
            if (settings.autoRefreshRepoList || !alreadyLoaded) {
                load()
            }
        }
    }

    fun onQueryChange(value: String) = _uiState.update { it.copy(query = value) }

    fun refresh() = load()

    private fun load() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            when (val result = repoRepository.listRepos(perPage = 100)) {
                is ApiResult.Success -> _uiState.update {
                    it.copy(isLoading = false, repos = result.data, hasLoadedOnce = true)
                }
                is ApiResult.Error -> _uiState.update { it.copy(isLoading = false, error = result.message) }
            }
        }
    }

    fun createRepo(name: String, description: String, private: Boolean) {
        viewModelScope.launch {
            _uiState.update { it.copy(actionInProgress = "create") }
            when (val result = repoRepository.createRepo(name, description.ifBlank { null }, private)) {
                is ApiResult.Success -> {
                    _uiState.update { it.copy(actionInProgress = null, repos = listOf(result.data) + it.repos, message = "Repository created.") }
                }
                is ApiResult.Error -> _uiState.update { it.copy(actionInProgress = null, error = result.message) }
            }
        }
    }

    fun updateRepo(repo: Repo, name: String?, description: String?, private: Boolean?, archived: Boolean?) {
        viewModelScope.launch {
            _uiState.update { it.copy(actionInProgress = repo.fullName) }
            val body = UpdateRepoRequest(name = name, description = description, isPrivate = private, archived = archived)
            when (val result = repoRepository.updateRepo(repo.owner.login, repo.name, body)) {
                is ApiResult.Success -> _uiState.update { state ->
                    state.copy(
                        actionInProgress = null,
                        repos = state.repos.map { if (it.id == repo.id) result.data else it },
                        message = "Repository updated."
                    )
                }
                is ApiResult.Error -> _uiState.update { it.copy(actionInProgress = null, error = result.message) }
            }
        }
    }

    fun deleteRepo(repo: Repo) {
        viewModelScope.launch {
            _uiState.update { it.copy(actionInProgress = repo.fullName) }
            when (val result = repoRepository.deleteRepo(repo.owner.login, repo.name)) {
                is ApiResult.Success -> _uiState.update { state ->
                    state.copy(actionInProgress = null, repos = state.repos.filterNot { it.id == repo.id }, message = "Repository deleted.")
                }
                is ApiResult.Error -> _uiState.update { it.copy(actionInProgress = null, error = result.message) }
            }
        }
    }

    fun forkRepo(repo: Repo) {
        viewModelScope.launch {
            _uiState.update { it.copy(actionInProgress = repo.fullName) }
            when (val result = repoRepository.forkRepo(repo.owner.login, repo.name)) {
                is ApiResult.Success -> _uiState.update { state ->
                    state.copy(actionInProgress = null, repos = listOf(result.data) + state.repos, message = "Forked to ${result.data.fullName}.")
                }
                is ApiResult.Error -> _uiState.update { it.copy(actionInProgress = null, error = result.message) }
            }
        }
    }

    fun duplicateRepo(source: Repo, newName: String, private: Boolean) {
        viewModelScope.launch {
            _uiState.update { it.copy(actionInProgress = source.fullName, duplicateProgress = 0 to 1) }
            val result = repoRepository.duplicateRepo(
                source.owner.login, source.name, source.defaultBranch,
                newName, private, source.description
            ) { done, total -> _uiState.update { it.copy(duplicateProgress = done to total) } }
            when (result) {
                is ApiResult.Success -> _uiState.update { state ->
                    state.copy(
                        actionInProgress = null, duplicateProgress = null,
                        repos = listOf(result.data) + state.repos,
                        message = "Duplicated as ${result.data.fullName}."
                    )
                }
                is ApiResult.Error -> _uiState.update { it.copy(actionInProgress = null, duplicateProgress = null, error = result.message) }
            }
        }
    }

    fun dismissError() = _uiState.update { it.copy(error = null) }
    fun dismissMessage() = _uiState.update { it.copy(message = null) }
}
