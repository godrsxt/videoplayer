package com.githubmanager.app.data.repository

import com.githubmanager.app.data.local.AccountStore
import com.githubmanager.app.data.model.GitHubUser
import com.githubmanager.app.data.remote.ApiResult
import com.githubmanager.app.data.remote.GitHubApiService
import com.githubmanager.app.data.remote.RetrofitProvider
import com.githubmanager.app.data.remote.safeApiCall

class AuthRepository(
    private val api: GitHubApiService,
    private val accountStore: AccountStore
) {
    fun isSignedIn(): Boolean = accountStore.isSignedIn()
    fun cachedUsername(): String? = accountStore.getCachedUsername()

    /**
     * Saves the entered username + token right away so the very next request
     * can use it, then validates the token against GitHub. If it works, the
     * stored username is reconciled to whatever the token's account actually
     * is (covers typos or case differences in what was typed). If it
     * doesn't, the half-saved session is cleared rather than left broken.
     */
    suspend fun signIn(username: String, token: String): ApiResult<GitHubUser> {
        accountStore.saveAccount(username.trim().removePrefix("@"), token.trim())
        val result = safeApiCall { api.getAuthenticatedUser() }
        if (result is ApiResult.Success) {
            accountStore.updateUsername(result.data.login)
        } else {
            accountStore.signOut()
        }
        return result
    }

    suspend fun signOut() {
        accountStore.signOut()
        RetrofitProvider.resetCache()
    }
}
