package com.githubmanager.app.util

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import com.githubmanager.app.data.repository.PendingFile
import java.io.ByteArrayOutputStream

private const val MAX_TOTAL_UNCOMPRESSED_BYTES = 200L * 1024 * 1024 // 200 MB

sealed class FolderReadResult {
    data class Success(val files: List<PendingFile>) : FolderReadResult()
    data class Error(val message: String) : FolderReadResult()
}

object DocumentTreeUtils {

    /** Recursively reads every file under a folder the user picked with
     *  ACTION_OPEN_DOCUMENT_TREE, producing paths relative to that folder
     *  (so the folder's own name becomes the top-level path segment). */
    fun readFolder(context: Context, treeUri: Uri): FolderReadResult {
        val root = DocumentFile.fromTreeUri(context, treeUri)
            ?: return FolderReadResult.Error("Couldn't open that folder.")
        val rootName = root.name ?: "upload"
        val files = mutableListOf<PendingFile>()
        var totalBytes = 0L

        fun walk(doc: DocumentFile, relativePath: String) {
            if (doc.isDirectory) {
                for (child in doc.listFiles()) {
                    val childName = child.name ?: continue
                    walk(child, joinPath(relativePath, childName))
                }
            } else if (doc.isFile) {
                context.contentResolver.openInputStream(doc.uri)?.use { input ->
                    val buffer = ByteArrayOutputStream()
                    val chunk = ByteArray(8 * 1024)
                    var read = input.read(chunk)
                    while (read != -1) {
                        totalBytes += read
                        buffer.write(chunk, 0, read)
                        read = input.read(chunk)
                    }
                    files += PendingFile(relativePath, buffer.toByteArray())
                }
            }
        }

        return try {
            walk(root, rootName)
            if (totalBytes > MAX_TOTAL_UNCOMPRESSED_BYTES) {
                FolderReadResult.Error("That folder is too large to upload in one go (over 200 MB). Try uploading a subfolder at a time.")
            } else if (files.isEmpty()) {
                FolderReadResult.Error("That folder doesn't contain any files.")
            } else {
                FolderReadResult.Success(files)
            }
        } catch (e: Exception) {
            FolderReadResult.Error("Couldn't read that folder: ${e.message ?: "unknown error"}")
        }
    }
}
