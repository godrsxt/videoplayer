package com.githubmanager.app.data.local

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.settingsDataStore by preferencesDataStore(name = "app_settings")

enum class ThemeMode { SYSTEM, LIGHT, DARK }

data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    // Data / loading behaviour
    val autoRefreshRepoList: Boolean = true,
    val loadFilePreviews: Boolean = true,
    val cacheRepoTreeForSearch: Boolean = true,
    val autoPollWorkflowRuns: Boolean = true,
    val pollIntervalSeconds: Int = 10,
    val itemsPerPage: Int = 30,
    // Safety / display
    val confirmBeforeDelete: Boolean = true,
    val showHiddenFiles: Boolean = false
)

/** Every toggle here exists so the app can be told to stop doing something —
 *  matching the "turn off what you don't need, save data you don't need
 *  loaded" settings screen. Nothing here is required for the app to work;
 *  it's all about cutting unnecessary API calls and background activity. */
class SettingsStore(private val context: Context) {

    private object Keys {
        val THEME = stringPreferencesKey("theme_mode")
        val AUTO_REFRESH_REPOS = booleanPreferencesKey("auto_refresh_repo_list")
        val FILE_PREVIEWS = booleanPreferencesKey("load_file_previews")
        val CACHE_TREE = booleanPreferencesKey("cache_repo_tree_for_search")
        val AUTO_POLL_RUNS = booleanPreferencesKey("auto_poll_workflow_runs")
        val POLL_INTERVAL = intPreferencesKey("poll_interval_seconds")
        val ITEMS_PER_PAGE = intPreferencesKey("items_per_page")
        val CONFIRM_DELETE = booleanPreferencesKey("confirm_before_delete")
        val SHOW_HIDDEN = booleanPreferencesKey("show_hidden_files")
    }

    val settingsFlow: Flow<AppSettings> = context.settingsDataStore.data.map { prefs ->
        AppSettings(
            themeMode = prefs[Keys.THEME]?.let { runCatching { ThemeMode.valueOf(it) }.getOrNull() } ?: ThemeMode.SYSTEM,
            autoRefreshRepoList = prefs[Keys.AUTO_REFRESH_REPOS] ?: true,
            loadFilePreviews = prefs[Keys.FILE_PREVIEWS] ?: true,
            cacheRepoTreeForSearch = prefs[Keys.CACHE_TREE] ?: true,
            autoPollWorkflowRuns = prefs[Keys.AUTO_POLL_RUNS] ?: true,
            pollIntervalSeconds = prefs[Keys.POLL_INTERVAL] ?: 10,
            itemsPerPage = prefs[Keys.ITEMS_PER_PAGE] ?: 30,
            confirmBeforeDelete = prefs[Keys.CONFIRM_DELETE] ?: true,
            showHiddenFiles = prefs[Keys.SHOW_HIDDEN] ?: false
        )
    }

    suspend fun setThemeMode(mode: ThemeMode) = update { it[Keys.THEME] = mode.name }
    suspend fun setAutoRefreshRepoList(value: Boolean) = update { it[Keys.AUTO_REFRESH_REPOS] = value }
    suspend fun setLoadFilePreviews(value: Boolean) = update { it[Keys.FILE_PREVIEWS] = value }
    suspend fun setCacheRepoTreeForSearch(value: Boolean) = update { it[Keys.CACHE_TREE] = value }
    suspend fun setAutoPollWorkflowRuns(value: Boolean) = update { it[Keys.AUTO_POLL_RUNS] = value }
    suspend fun setPollIntervalSeconds(value: Int) = update { it[Keys.POLL_INTERVAL] = value }
    suspend fun setItemsPerPage(value: Int) = update { it[Keys.ITEMS_PER_PAGE] = value }
    suspend fun setConfirmBeforeDelete(value: Boolean) = update { it[Keys.CONFIRM_DELETE] = value }
    suspend fun setShowHiddenFiles(value: Boolean) = update { it[Keys.SHOW_HIDDEN] = value }

    private suspend fun update(block: (androidx.datastore.preferences.core.MutablePreferences) -> Unit) {
        context.settingsDataStore.edit(block)
    }
}
