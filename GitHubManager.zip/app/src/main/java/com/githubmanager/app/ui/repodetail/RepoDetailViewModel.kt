package com.githubmanager.app.ui.repodetail

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.githubmanager.app.data.model.Branch
import com.githubmanager.app.data.model.Repo
import com.githubmanager.app.data.remote.ApiResult
import com.githubmanager.app.data.repository.RepoRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class RepoDetailUiState(
    val isLoading: Boolean = true,
    val repo: Repo? = null,
    val branches: List<Branch> = emptyList(),
    val selectedBranch: String = "",
    val error: String? = null
)

class RepoDetailViewModel(
    private val repoRepository: RepoRepository,
    private val owner: String,
    private val repoName: String
) : ViewModel() {

    private val _uiState = MutableStateFlow(RepoDetailUiState())
    val uiState: StateFlow<RepoDetailUiState> = _uiState

    init {
        load()
    }

    fun load() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            val repoResult = repoRepository.getRepo(owner, repoName)
            if (repoResult is ApiResult.Error) {
                _uiState.update { it.copy(isLoading = false, error = repoResult.message) }
                return@launch
            }
            val repo = (repoResult as ApiResult.Success).data
            val branchesResult = repoRepository.listBranches(owner, repoName)
            val branches = (branchesResult as? ApiResult.Success)?.data ?: emptyList()
            _uiState.update {
                it.copy(
                    isLoading = false,
                    repo = repo,
                    branches = branches,
                    selectedBranch = if (it.selectedBranch.isBlank()) repo.defaultBranch else it.selectedBranch
                )
            }
        }
    }

    fun selectBranch(name: String) = _uiState.update { it.copy(selectedBranch = name) }
}
