package com.githubmanager.app.data.repository

import com.githubmanager.app.data.model.Artifact
import com.githubmanager.app.data.remote.ApiResult
import com.githubmanager.app.data.remote.GitHubApiService
import com.githubmanager.app.data.remote.RetrofitProvider
import com.githubmanager.app.data.remote.safeApiCall
import okhttp3.Request
import java.io.IOException

class ArtifactRepository(
    private val api: GitHubApiService,
    private val authToken: () -> String?
) {
    suspend fun listArtifacts(owner: String, repo: String): ApiResult<List<Artifact>> {
        return when (val result = safeApiCall { api.listArtifacts(owner, repo) }) {
            is ApiResult.Success -> ApiResult.Success(result.data.artifacts)
            is ApiResult.Error -> result
        }
    }

    suspend fun deleteArtifact(owner: String, repo: String, artifactId: Long): ApiResult<Unit> =
        safeApiCall { api.deleteArtifact(owner, repo, artifactId) }

    /**
     * GitHub answers the authenticated artifact-download endpoint with a 302
     * to a short-lived, pre-signed storage URL that needs no auth header of
     * its own. This makes one non-redirecting authenticated request purely
     * to read that `Location` header; the caller (DownloadManager, in this
     * app) fetches the actual bytes from the returned URL directly.
     */
    suspend fun resolveDownloadUrl(owner: String, repo: String, artifactId: Long): ApiResult<String> {
        return try {
            val client = RetrofitProvider.rawRedirectProbeClient()
            val request = Request.Builder()
                .url("https://api.github.com/repos/$owner/$repo/actions/artifacts/$artifactId/zip")
                .header("Authorization", "Bearer ${authToken().orEmpty()}")
                .header("Accept", "application/vnd.github+json")
                .header("X-GitHub-Api-Version", "2022-11-28")
                .build()
            client.newCall(request).execute().use { response ->
                val location = response.header("Location")
                when {
                    response.code in 300..399 && location != null -> ApiResult.Success(location)
                    response.isSuccessful -> ApiResult.Error("Expected a download link but didn't get one.")
                    response.code == 410 -> ApiResult.Error("This artifact has expired and is no longer available.")
                    else -> ApiResult.Error("Couldn't resolve the download link (HTTP ${response.code}).")
                }
            }
        } catch (e: IOException) {
            ApiResult.Error("Couldn't reach GitHub to resolve the download link.")
        }
    }
}
