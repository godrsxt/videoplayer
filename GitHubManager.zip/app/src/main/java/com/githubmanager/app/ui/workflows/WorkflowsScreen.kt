@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.githubmanager.app.ui.workflows
import androidx.compose.foundation.clickable

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.githubmanager.app.data.model.Workflow
import com.githubmanager.app.data.model.WorkflowRun
import com.githubmanager.app.ui.GenericViewModelFactory
import com.githubmanager.app.ui.common.ConfirmDialog
import com.githubmanager.app.ui.common.EmptyState
import com.githubmanager.app.ui.common.ErrorView
import com.githubmanager.app.ui.common.LoadingIndicator
import com.githubmanager.app.ui.rememberAppContainer
import com.githubmanager.app.util.formatIsoDate

@Composable
fun WorkflowsScreen(owner: String, repo: String, branch: String) {
    val container = rememberAppContainer()
    val viewModel: WorkflowsViewModel = viewModel(
        key = "workflows-$owner-$repo",
        factory = GenericViewModelFactory {
            WorkflowsViewModel(container.workflowRepository, container.contentsRepository, container.settingsStore, owner, repo, branch)
        }
    )
    val state by viewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    var deleteTarget by remember { mutableStateOf<Workflow?>(null) }
    var dispatchTarget by remember { mutableStateOf<Workflow?>(null) }

    LaunchedEffect(state.message) { state.message?.let { snackbarHostState.showSnackbar(it); viewModel.dismissMessage() } }

    if (state.selectedWorkflow != null) {
        BackHandler { viewModel.closeRuns() }
        RunsList(state = state, onBack = viewModel::closeRuns, onRefresh = viewModel::loadRuns, onCancel = viewModel::cancelRun, onDelete = viewModel::deleteRun)
        return
    }

    Box(Modifier.fillMaxSize()) {
        when {
            state.isLoading -> LoadingIndicator(label = "Loading workflows…")
            state.error != null && state.workflows.isEmpty() -> ErrorView(state.error!!, onRetry = viewModel::load)
            state.workflows.isEmpty() -> EmptyState(
                title = "No workflows found",
                subtitle = "Add a .yml file under .github/workflows to see it here."
            )
            else -> LazyColumn {
                items(state.workflows, key = { it.id }) { workflow ->
                    WorkflowRow(
                        workflow = workflow,
                        busy = state.busyWorkflowId == workflow.id,
                        onClick = { viewModel.openRuns(workflow) },
                        onToggleEnabled = { viewModel.setEnabled(workflow, workflow.state != "active") },
                        onRun = { dispatchTarget = workflow },
                        onDelete = { deleteTarget = workflow }
                    )
                    HorizontalDivider()
                }
            }
        }
        SnackbarHost(snackbarHostState, modifier = Modifier.align(Alignment.BottomCenter))
    }

    deleteTarget?.let { workflow ->
        ConfirmDialog(
            title = "Delete ${workflow.name}?",
            message = "This removes the workflow file (${workflow.path}) from the repository.",
            confirmLabel = "Delete",
            destructive = true,
            onConfirm = { viewModel.deleteWorkflowFile(workflow); deleteTarget = null },
            onDismiss = { deleteTarget = null }
        )
    }
    dispatchTarget?.let { workflow ->
        com.githubmanager.app.ui.common.TextInputDialog(
            title = "Run ${workflow.name}",
            label = "Branch or tag",
            initialValue = branch,
            confirmLabel = "Run",
            validate = { if (it.isBlank()) "Enter a branch or tag." else null },
            onConfirm = { ref -> viewModel.dispatch(workflow, ref); dispatchTarget = null },
            onDismiss = { dispatchTarget = null }
        )
    }
}

@Composable
private fun WorkflowRow(workflow: Workflow, busy: Boolean, onClick: () -> Unit, onToggleEnabled: () -> Unit, onRun: () -> Unit, onDelete: () -> Unit) {
    ListItem(
        headlineContent = { Text(workflow.name, fontWeight = FontWeight.Medium) },
        supportingContent = { Text(if (workflow.state == "active") "Active" else "Disabled", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) },
        leadingContent = { Icon(Icons.Filled.PlayCircleOutline, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
        trailingContent = {
            if (busy) {
                CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
            } else {
                Row {
                    IconButton(onClick = onRun) { Icon(Icons.Filled.PlayArrow, contentDescription = "Run workflow") }
                    IconButton(onClick = onToggleEnabled) {
                        Icon(if (workflow.state == "active") Icons.Filled.PauseCircle else Icons.Filled.CheckCircle, contentDescription = if (workflow.state == "active") "Disable" else "Enable")
                    }
                    IconButton(onClick = onDelete) { Icon(Icons.Filled.Delete, contentDescription = "Delete workflow") }
                }
            }
        },
        modifier = Modifier.clickable(onClick = onClick)
    )
}

@Composable
private fun RunsList(
    state: WorkflowsUiState,
    onBack: () -> Unit,
    onRefresh: () -> Unit,
    onCancel: (WorkflowRun) -> Unit,
    onDelete: (WorkflowRun) -> Unit
) {
    val context = LocalContext.current
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(state.selectedWorkflow?.name.orEmpty(), fontWeight = FontWeight.SemiBold) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") } },
                actions = { IconButton(onClick = onRefresh) { Icon(Icons.Filled.Refresh, contentDescription = "Refresh") } }
            )
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when {
                state.isLoadingRuns && state.runs.isEmpty() -> LoadingIndicator(label = "Loading runs…")
                state.runs.isEmpty() -> EmptyState(title = "No runs yet", subtitle = "Trigger a run to see it appear here.")
                else -> LazyColumn {
                    items(state.runs, key = { it.id }) { run ->
                        RunRow(run = run, busy = state.busyRunId == run.id, onCancel = { onCancel(run) }, onDelete = { onDelete(run) }, onOpenInBrowser = {
                            context.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(run.htmlUrl)))
                        })
                        HorizontalDivider()
                    }
                }
            }
        }
    }
}

@Composable
private fun RunRow(run: WorkflowRun, busy: Boolean, onCancel: () -> Unit, onDelete: () -> Unit, onOpenInBrowser: () -> Unit) {
    ListItem(
        headlineContent = { Text(run.displayTitle ?: "Run #${run.runNumber}", fontWeight = FontWeight.Medium) },
        supportingContent = {
            Text(
                "${run.headBranch.orEmpty()} • ${run.event} • ${formatIsoDate(run.createdAt)}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        },
        leadingContent = { StatusDot(run) },
        trailingContent = {
            if (busy) {
                CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
            } else {
                Row {
                    if (run.status != "completed") {
                        IconButton(onClick = onCancel) { Icon(Icons.Filled.Cancel, contentDescription = "Cancel run") }
                    }
                    IconButton(onClick = onDelete) { Icon(Icons.Filled.Delete, contentDescription = "Delete run") }
                }
            }
        },
        modifier = Modifier.clickable(onClick = onOpenInBrowser)
    )
}

@Composable
private fun StatusDot(run: WorkflowRun) {
    val color = when {
        run.status != "completed" -> MaterialTheme.colorScheme.tertiary
        run.conclusion == "success" -> MaterialTheme.colorScheme.primary
        run.conclusion == "failure" -> MaterialTheme.colorScheme.error
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }
    val icon = when {
        run.status != "completed" -> Icons.Filled.Autorenew
        run.conclusion == "success" -> Icons.Filled.CheckCircle
        run.conclusion == "failure" -> Icons.Filled.Cancel
        else -> Icons.Filled.RemoveCircle
    }
    Icon(icon, contentDescription = run.conclusion ?: run.status, tint = color)
}
